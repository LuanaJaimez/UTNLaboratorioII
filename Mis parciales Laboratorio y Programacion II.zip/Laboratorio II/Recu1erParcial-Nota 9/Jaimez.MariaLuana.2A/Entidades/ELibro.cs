﻿public enum ELibro
{
    PrecioDeManuales,
    PrecioDeNovelas,
    PrecioTotal
}