﻿public enum ETipo
{
    Tecnico,
    Escolar,
    Finanzas
}