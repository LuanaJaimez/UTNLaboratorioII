﻿namespace WindowsForms.SP
{
    partial class SegundoParcial
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnVerLog = new System.Windows.Forms.Button();
            this.txtVisorTickets = new System.Windows.Forms.TextBox();
            this.btnPunto10 = new System.Windows.Forms.Button();
            this.btnPunto9 = new System.Windows.Forms.Button();
            this.btnPunto8 = new System.Windows.Forms.Button();
            this.btnPunto7 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnPunto6 = new System.Windows.Forms.Button();
            this.btnPunto5 = new System.Windows.Forms.Button();
            this.btnPunto4 = new System.Windows.Forms.Button();
            this.btnPunto3 = new System.Windows.Forms.Button();
            this.btnPunto2 = new System.Windows.Forms.Button();
            this.btnPunto1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnVerLog
            // 
            this.btnVerLog.Location = new System.Drawing.Point(483, 231);
            this.btnVerLog.Name = "btnVerLog";
            this.btnVerLog.Size = new System.Drawing.Size(205, 23);
            this.btnVerLog.TabIndex = 27;
            this.btnVerLog.Text = "Ver log de tickets";
            this.btnVerLog.UseVisualStyleBackColor = true;
            this.btnVerLog.Click += new System.EventHandler(this.btnVerLog_Click);
            // 
            // txtVisorTickets
            // 
            this.txtVisorTickets.Location = new System.Drawing.Point(483, 46);
            this.txtVisorTickets.Multiline = true;
            this.txtVisorTickets.Name = "txtVisorTickets";
            this.txtVisorTickets.Size = new System.Drawing.Size(205, 179);
            this.txtVisorTickets.TabIndex = 26;
            // 
            // btnPunto10
            // 
            this.btnPunto10.Location = new System.Drawing.Point(337, 231);
            this.btnPunto10.Name = "btnPunto10";
            this.btnPunto10.Size = new System.Drawing.Size(75, 23);
            this.btnPunto10.TabIndex = 25;
            this.btnPunto10.Text = "Punto 10";
            this.btnPunto10.UseVisualStyleBackColor = true;
            this.btnPunto10.Click += new System.EventHandler(this.btnPunto10_Click);
            // 
            // btnPunto9
            // 
            this.btnPunto9.Location = new System.Drawing.Point(256, 231);
            this.btnPunto9.Name = "btnPunto9";
            this.btnPunto9.Size = new System.Drawing.Size(75, 23);
            this.btnPunto9.TabIndex = 24;
            this.btnPunto9.Text = "Punto 9";
            this.btnPunto9.UseVisualStyleBackColor = true;
            this.btnPunto9.Click += new System.EventHandler(this.btnPunto9_Click);
            // 
            // btnPunto8
            // 
            this.btnPunto8.Location = new System.Drawing.Point(175, 231);
            this.btnPunto8.Name = "btnPunto8";
            this.btnPunto8.Size = new System.Drawing.Size(75, 23);
            this.btnPunto8.TabIndex = 23;
            this.btnPunto8.Text = "Punto 8";
            this.btnPunto8.UseVisualStyleBackColor = true;
            this.btnPunto8.Click += new System.EventHandler(this.btnPunto8_Click);
            // 
            // btnPunto7
            // 
            this.btnPunto7.Location = new System.Drawing.Point(94, 231);
            this.btnPunto7.Name = "btnPunto7";
            this.btnPunto7.Size = new System.Drawing.Size(75, 23);
            this.btnPunto7.TabIndex = 22;
            this.btnPunto7.Text = "Punto 7";
            this.btnPunto7.UseVisualStyleBackColor = true;
            this.btnPunto7.Click += new System.EventHandler(this.btnPunto7_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(455, 179);
            this.dataGridView1.TabIndex = 21;
            // 
            // btnPunto6
            // 
            this.btnPunto6.Location = new System.Drawing.Point(13, 231);
            this.btnPunto6.Name = "btnPunto6";
            this.btnPunto6.Size = new System.Drawing.Size(75, 23);
            this.btnPunto6.TabIndex = 20;
            this.btnPunto6.Text = "Punto 6";
            this.btnPunto6.UseVisualStyleBackColor = true;
            this.btnPunto6.Click += new System.EventHandler(this.btnPunto6_Click);
            // 
            // btnPunto5
            // 
            this.btnPunto5.Location = new System.Drawing.Point(337, 17);
            this.btnPunto5.Name = "btnPunto5";
            this.btnPunto5.Size = new System.Drawing.Size(75, 23);
            this.btnPunto5.TabIndex = 19;
            this.btnPunto5.Text = "Punto 5";
            this.btnPunto5.UseVisualStyleBackColor = true;
            this.btnPunto5.Click += new System.EventHandler(this.btnPunto5_Click);
            // 
            // btnPunto4
            // 
            this.btnPunto4.Location = new System.Drawing.Point(256, 17);
            this.btnPunto4.Name = "btnPunto4";
            this.btnPunto4.Size = new System.Drawing.Size(75, 23);
            this.btnPunto4.TabIndex = 18;
            this.btnPunto4.Text = "Punto 4";
            this.btnPunto4.UseVisualStyleBackColor = true;
            this.btnPunto4.Click += new System.EventHandler(this.btnPunto4_Click);
            // 
            // btnPunto3
            // 
            this.btnPunto3.Location = new System.Drawing.Point(175, 17);
            this.btnPunto3.Name = "btnPunto3";
            this.btnPunto3.Size = new System.Drawing.Size(75, 23);
            this.btnPunto3.TabIndex = 17;
            this.btnPunto3.Text = "Punto 3";
            this.btnPunto3.UseVisualStyleBackColor = true;
            this.btnPunto3.Click += new System.EventHandler(this.btnPunto3_Click);
            // 
            // btnPunto2
            // 
            this.btnPunto2.Location = new System.Drawing.Point(94, 17);
            this.btnPunto2.Name = "btnPunto2";
            this.btnPunto2.Size = new System.Drawing.Size(75, 23);
            this.btnPunto2.TabIndex = 16;
            this.btnPunto2.Text = "Punto 2";
            this.btnPunto2.UseVisualStyleBackColor = true;
            this.btnPunto2.Click += new System.EventHandler(this.btnPunto2_Click);
            // 
            // btnPunto1
            // 
            this.btnPunto1.Location = new System.Drawing.Point(13, 17);
            this.btnPunto1.Name = "btnPunto1";
            this.btnPunto1.Size = new System.Drawing.Size(75, 23);
            this.btnPunto1.TabIndex = 15;
            this.btnPunto1.Text = "Punto 1";
            this.btnPunto1.UseVisualStyleBackColor = true;
            this.btnPunto1.Click += new System.EventHandler(this.btnPunto1_Click);
            // 
            // SegundoParcial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 270);
            this.Controls.Add(this.btnVerLog);
            this.Controls.Add(this.txtVisorTickets);
            this.Controls.Add(this.btnPunto10);
            this.Controls.Add(this.btnPunto9);
            this.Controls.Add(this.btnPunto8);
            this.Controls.Add(this.btnPunto7);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnPunto6);
            this.Controls.Add(this.btnPunto5);
            this.Controls.Add(this.btnPunto4);
            this.Controls.Add(this.btnPunto3);
            this.Controls.Add(this.btnPunto2);
            this.Controls.Add(this.btnPunto1);
            this.Name = "SegundoParcial";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.SegundoParcial_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnVerLog;
        private System.Windows.Forms.TextBox txtVisorTickets;
        private System.Windows.Forms.Button btnPunto10;
        private System.Windows.Forms.Button btnPunto9;
        private System.Windows.Forms.Button btnPunto8;
        private System.Windows.Forms.Button btnPunto7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnPunto6;
        private System.Windows.Forms.Button btnPunto5;
        private System.Windows.Forms.Button btnPunto4;
        private System.Windows.Forms.Button btnPunto3;
        private System.Windows.Forms.Button btnPunto2;
        private System.Windows.Forms.Button btnPunto1;
    }
}

